This is my final project for this course. I used the Final.py file to run all my code and change the intial conditions based on the requirements.
I followed the milestones and tested for each case as well. The Xerr resulting from all the cases makes sense as it quickly tries to snap to the 
origin before moving along the desired trajectory segments. The only issue I faced was in creating the functions. Determining what to pass into the 
function and what to keep out in the main program was a little ambiguous. Otherwise the project was straighforward in terms of execution. 

Thank you. 