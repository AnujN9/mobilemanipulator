These were the values I used for the gains of the PI controller and
intial condition of the youbot Robot.

kp = 5
ki = 0.1
init_config = np.array([0.2, -0.5, -0.5, 0.1, -0.4, 0.2, -1.6, 0.1,0,0,0,0,0])
