These were the values I used for the gains of the PI controller and
intial condition of the youbot Robot. The overshoot is noticable in the video.

kp = 2
ki = 5
init_config = np.array([0.5, -0.5, 1.5, 0.1, -0.4, 0.2, -1.6, 0.1,0,0,0,0,0])

